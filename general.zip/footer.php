<footer class="main-footer">
    <strong>Copyright &copy; 2024, <a href="https://www.phichai.ac.th">by ICT @Phichai school</a>. พัฒนาระบบโดย นายทิวา  เรืองศรี ทีมงาน ICT โรงเรียนพิชัย</strong>

    <div class="float-right d-none d-sm-inline-block">
    </div>
</footer>

